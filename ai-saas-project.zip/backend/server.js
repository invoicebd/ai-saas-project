const express = require("express");
const cors = require("cors");
const fetch = require("node-fetch");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/chat", async (req,res)=>{
  const userMessage = req.body.message;

  try{
    const response = await fetch("https://api.openai.com/v1/chat/completions",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization":"Bearer YOUR_API_KEY"
      },
      body:JSON.stringify({
        model:"gpt-4o-mini",
        messages:[{role:"user",content:userMessage}]
      })
    });

    const data = await response.json();
    res.json({reply:data.choices[0].message.content});

  }catch(err){
    res.json({reply:"Error"});
  }
});

app.listen(3000,()=>console.log("Server running"));
